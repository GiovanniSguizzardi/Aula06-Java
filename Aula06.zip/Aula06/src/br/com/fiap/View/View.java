package br.com.fiap.View;
import br.com.fiap.ContaCorrente;
import br.com.fiap.ContaPoupança;
import java.util.ArrayList;
import java.util.List;

public class View{
    public static void main(String[] args){

    ContaCorrente cc = new ContaCorrente("Daniel", 987654321, 1500);
        System.out.println(cc);
    ContaPoupança cp = new ContaPoupança("Hugo", 1234567890, 2500);
        System.out.println(cp);

        cc.retirar(cc, cc.saldo);
        System.out.println("Novo saldo: " + cc.getSaldo());

    List listacorrentes = new ArrayList<>();
            ContaCorrente cc1 = new ContaCorrente("Hugo", 987654321, 1560);
            ContaCorrente cc2 = new ContaCorrente("Mauricio", 983644128, 1800);
            ContaCorrente cc3 = new ContaCorrente("Oswaldo", 971632301, 1750);

            System.out.println(cc1);
            System.out.println(cc2);
            System.out.println(cc3);
    }
}