package br.com.fiap;

public class ContaPoupança extends Conta{

    public ContaPoupança(String nome, long cpf, int saldo) {
        super(nome, cpf, saldo);
    }
}