package br.com.fiap.Exception;

public class SaldoInsuficienteException {
}
