package br.com.fiap;

import br.com.fiap.Enum.TipoConta;

public class ContaCorrente extends Conta{

    public ContaCorrente(String nome, long cpf, int saldo) {
        super(nome, cpf, saldo);
    }

    public void retirar(Conta c, int saldo){
        c.saldo = saldo - 500;
    }
}
