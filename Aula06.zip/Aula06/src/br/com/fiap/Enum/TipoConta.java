package br.com.fiap.Enum;
public enum TipoConta {
    OURO, PRATA, COBRE
}
