package br.com.fiap;

public class ContaInvestimento extends Conta{
    public ContaInvestimento(String nome, long cpf, int saldo) {
        super(nome, cpf, saldo);
    }
}
