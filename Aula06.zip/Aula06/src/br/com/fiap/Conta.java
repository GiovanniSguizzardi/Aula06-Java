package br.com.fiap;

public class Conta {
    private String nome;
    private long cpf;
    public int saldo;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public Conta(String nome, long cpf, int saldo) {
        this.nome = nome;
        this.cpf = cpf;
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "[Informações Conta]" + "\r\n" +
                "Nome: " + nome + "\r\n" +
                "Cpf: " + cpf + "\r\n" +
                "Saldo: " + saldo + "\r\n";
    }
}